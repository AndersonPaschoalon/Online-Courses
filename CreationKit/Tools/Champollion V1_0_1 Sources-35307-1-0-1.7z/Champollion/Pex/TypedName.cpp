#include "TypedName.hpp"


/**
 * @brief Default constructor
 */
Pex::TypedName::TypedName()
{
}

/**
 * @brief Default destructor
 */
Pex::TypedName::~TypedName()
{
}
