#include "OutputWriter.hpp"


/**
 * @brief Default constructor.
 */
Decompiler::OutputWriter::OutputWriter()
{
}

/**
 * @brief Default destructor.
 */
Decompiler::OutputWriter::~OutputWriter()
{
}
