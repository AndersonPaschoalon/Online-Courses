Champollion decompiler for Skyrim Papyrus
Copyright (c) 2013 Paul-Henry Perrin
See COPYING.txt for the LGPL V3 license.

Dependencies
============

* Boost 1.52 http://www.boost.org/
* QtCreator 2.7.0 and a header of QT 5.0 http://qt-project.org/ 
* A C++11 compiler (for Windows : http://www.microsoft.com/visualstudio/eng/downloads)

Edit the Project.pri to point to the correct directories.